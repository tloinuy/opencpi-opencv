
export BASE=/home/mpepe/projects/opencpi

export OCPI_BASE="$BASE"/opencpi
export OCPIDIR="$OCPI_BASE"

export OCPI_DIR="$OCPI_BASE"/ocpi

