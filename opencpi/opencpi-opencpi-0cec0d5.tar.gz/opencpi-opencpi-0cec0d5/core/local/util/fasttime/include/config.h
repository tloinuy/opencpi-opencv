
/* config.h.in is copied to config.h with substitutions made by
 * the configure script.
 */

#ifndef CONFIG_H
#define CONFIG_H

//#define _CPU_POWERPC
#define _CPU_IA64

#include <stdint.h>

#endif
